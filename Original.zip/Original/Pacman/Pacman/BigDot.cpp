#include "BigDot.h"

BigDot::BigDot(Vector2f aPosition)
: StaticGameEntity(aPosition, "Big_Dot_32.png")
{
}

BigDot::~BigDot(void)
{
}
