#include "Cherry.h"

Cherry::Cherry(Vector2f aPosition)
: StaticGameEntity(aPosition, "dot.png")
{
}

Cherry::~Cherry(void)
{
}
