#include "Dot.h"

Dot::Dot(Vector2f aPosition)
: StaticGameEntity(aPosition, "Small_Dot_32.png")
{
}

Dot::~Dot(void)
{
}
