#include "StaticGameEntity.h"

StaticGameEntity::StaticGameEntity(Vector2f aPosition, const char* anImage)
: GameEntity(aPosition, anImage)
{
}

StaticGameEntity::~StaticGameEntity(void)
{
}
