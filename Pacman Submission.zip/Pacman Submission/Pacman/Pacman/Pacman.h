#ifndef PACMAN_H
#define PACMAN_H

#include <vector>
#include <sstream>

#include "Avatar.h"
#include "Ghost.h"

struct SDL_Surface;
class Drawer;
class Sprite;
class Avatar;
class World;
class Ghost;

class Pacman
{
public:
	static Pacman* Create(Drawer*);
	~Pacman(void);

	bool update(float);	
	bool draw();

private:
	Pacman(Drawer*);

	bool checkEndGameCondition();
	bool updateInput();

	void checkTimers(float);
	void drawText();
	void hitGhost();
	void updateScore();

	float cherry_timer = 0.0f;
	float ghost_vulnerable_timer = 0.0f;
	float immortal_timer = 0.0f;
	float time_to_next_update = 0.0f;

	int big_dot_score = 20;
	int cherry_score = 100;
	int dot_score = 10;
	int fps = 0;	
	int ghost_score = 50;
	int lives = 3;
	int score = 0;
	int score_threshhold = 2000;

	const int tile_size = 22;

	const Uint8* keystate = SDL_GetKeyboardState(NULL);

	Vector2f next_movement = { -1.0f, 0.0f };

	const Vector2f cherry_spawn = { 13.0f, 16.0f };
	const Vector2f ghost_spawn = { 13.0f, 13.0f };
	const Vector2f player_spawn = { 13.0f, 22.0f };

	std::vector<Ghost*> ghosts;
	
	Avatar* player = nullptr;
	Cherry* cherry = nullptr;
	Drawer* renderer = nullptr;
	Ghost* ghost = nullptr;
	Sprite* player_sprite = nullptr;
	World* world = nullptr;
};

#endif // PACMAN_H